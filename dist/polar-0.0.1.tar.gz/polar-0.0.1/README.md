# polar
 A suite of signal pole estimation algorithms
